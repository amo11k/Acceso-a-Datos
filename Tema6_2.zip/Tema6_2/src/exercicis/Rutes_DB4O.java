package exercicis;

public class Rutes_DB4O {

	public static void main(String[] args) {
		Rutes_DB4O_pantalla finestra = new Rutes_DB4O_pantalla();
		finestra.iniciar();
	}
}